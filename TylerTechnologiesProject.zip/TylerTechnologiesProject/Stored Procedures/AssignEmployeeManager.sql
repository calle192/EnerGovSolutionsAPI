-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Christopher Allen
-- Create date: 2-9-25
-- Description:	-<Description,,>
-- =============================================
CREATE PROCEDURE AssignEmployeeManager 
	@ManagerId int, 
	@EmployeeId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @EmpExists int
	set @EmpExists = (SELECT COUNT(*) FROM Employee_Hierarchy WHERE Employee_Id = @EmployeeId)
	
	IF @EmpExists > 0
		BEGIN
			UPDATE Employee_Hierarchy SET Supervised_By_Id = @ManagerId WHERE Employee_Id = @EmployeeId
		END
	ELSE
		BEGIN
			INSERT INTO Employee_Hierarchy(Supervised_By_Id,Employee_Id) VALUES(@ManagerId,@EmployeeId);
		END
END
GO
