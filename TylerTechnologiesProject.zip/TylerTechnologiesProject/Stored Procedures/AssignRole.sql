-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Christopher Allen
-- Create date: 2-9-25
-- Description:	-<Description,,>
-- =============================================
CREATE PROCEDURE AssignRole 
	-- Add the parameters for the stored procedure here
	@RoleId INT,
	@EmployeeId INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @count int
	set @count = (select count(*) from Employee_Roles where Role_Id = @RoleId and Employee_Id = @EmployeeId)

	if @count = 0
		begin
			insert into Employee_Roles (Employee_Id, Role_Id) values(@EmployeeId, @RoleId)
		end
END
GO
