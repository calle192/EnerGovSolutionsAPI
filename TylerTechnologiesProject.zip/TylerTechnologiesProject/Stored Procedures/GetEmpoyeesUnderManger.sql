-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Christopher Allen
-- Create date: 2-9-25
-- Description:	-<Description,,>
-- =============================================
CREATE PROCEDURE GetEmpoyeesUnderManger 
	-- Add the parameters for the stored procedure here
	@ManagerId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT Employees.id,Employees.FName,Employees.LName
	FROM Employee_Hierarchy 
	INNER JOIN Employees ON Employee_Hierarchy.Employee_Id = Employees.id
	WHERE Supervised_By_Id = @ManagerId
END
GO
