create database Energov_Solutions

USE Energov_Solutions;
create table dbo.Employees (id int primary key identity(1,1), FName varchar(75), LName varchar(75))

create table dbo.roles (id int primary key identity(1,1), name varchar (75))

create table dbo.Employee_Roles (Employee_Id int foreign key references Employees(Id) on delete cascade, 
                             Role_Id int foreign key references Roles(Id) on delete cascade)

create table Energov_Solutions.dbo.Employee_Hierarchy (Employee_Id int foreign key references Employees(Id) on delete cascade,
                                  Supervised_By_Id int foreign key references Employees(Id) on delete no action)